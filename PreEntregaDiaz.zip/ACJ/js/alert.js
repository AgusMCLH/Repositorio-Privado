document.getElementById('NA').addEventListener('click', function (e) {
  e.preventDefault();
  alert('No disponible todavia');
});
document.getElementById('NA2').addEventListener('click', function (e) {
  e.preventDefault();
  alert('No disponible todavia');
});
